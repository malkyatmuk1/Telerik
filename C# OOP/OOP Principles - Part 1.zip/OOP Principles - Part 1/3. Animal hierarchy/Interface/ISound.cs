﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sound1
{
    interface ISound
    {
       void Sound();
    }
}
