﻿namespace Problem_2.Bank_accounts.Interface
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    interface IDeposit
    {
        void MakeDeposit(int sum);
    }
}
