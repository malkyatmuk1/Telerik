﻿namespace Divisible_by_7_and_3
{
    using System;
    using System.Collections.Generic;
    class Program
    {
       
        static void Main(string[] args)
        {
            List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 21 };
            Console.WriteLine("Problem #6");
            numbers.Divisible();



        }
    }
}
